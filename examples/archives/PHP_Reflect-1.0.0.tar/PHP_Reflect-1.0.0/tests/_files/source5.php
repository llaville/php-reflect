<?php
namespace A\B;

class Foo { }
function Bar() {}
