<?php
/**
 * Unit tests for PHP_CompatInfo package, Mysql Reference
 *
 * @package    PHP_CompatInfo
 * @subpackage Tests
 * @author     Remi Collet <Remi@FamilleCollet.com>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License
 * @version    Release: 2.0.0
 * @link       http://php5.laurent-laville.org/compatinfo/
 * @since      Class available since Release 2.0.0RC4
 */

require_once 'GenericTest.php';

/**
 * Tests for the PHP_CompatInfo class, retrieving components informations
 * about Mysql extension
 */
class PHP_CompatInfo_Reference_MysqlTest extends PHP_CompatInfo_Reference_GenericTest
{
    /**
     * @covers PHP_CompatInfo_Reference_Mysql::getExtensions
     * @covers PHP_CompatInfo_Reference_Mysql::getFunctions
     * @covers PHP_CompatInfo_Reference_Mysql::getConstants
     */
    protected function setUp()
    {
        $this->optionnalfunctions = array(
            // deprecated, requires MySQL < 4
            'mysql_create_db',
            'mysql_drop_db',
        );
        $this->obj = new PHP_CompatInfo_Reference_Mysql();
        parent::setUp();
    }
}
