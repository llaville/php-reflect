<?php 
class Foo_Exception extends Exception {}
