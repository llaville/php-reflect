<?php 
include("File.php"); 
File::write('test', 'test');
