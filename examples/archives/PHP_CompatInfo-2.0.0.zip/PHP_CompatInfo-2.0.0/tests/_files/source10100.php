<?php
class Test 
{ 
    function test() 
    { 
        $test = "public$link"; 
    } 
} 
