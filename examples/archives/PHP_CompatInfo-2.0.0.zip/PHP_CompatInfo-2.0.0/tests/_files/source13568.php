<?php
class Test
{
    function connect()
    {}
    function disconnect()
    {}
}
